package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.util.function.Supplier;

/** A row with the module name on the left and a capsule on/off switch on the right,
 *  in the style of the usual third-party visual-client menus. Debounced like GlowButton,
 *  so one touchscreen tap can't skip through several states. */
public class ToggleButton {
    private static final long DEBOUNCE_MS = 180;

    private final int x, y, w, h;
    private final String label;
    private final Supplier<Boolean> state;
    private final Runnable action;
    private float anim;
    private long lastClick = 0;

    public ToggleButton(int x, int y, int w, int h, String label, Supplier<Boolean> state, Runnable action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.state = state;
        this.action = action;
        this.anim = (state != null && state.get()) ? 1f : 0f;
    }

    public boolean click(double mx, double my) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            long now = System.currentTimeMillis();
            if (now - lastClick >= DEBOUNCE_MS) {
                lastClick = now;
                action.run();
            }
            return true;
        }
        return false;
    }

    public void render(MatrixStack m, int mx, int my) {
        boolean on = state != null && state.get();
        anim += ((on ? 1f : 0f) - anim) * 0.3f;
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;

        Gfx.roundRect(m, x, y, w, h, 5, hover ? 0xFF17171D : 0xFF101014);

        int swW = 22, swH = 11;
        int swX = x + w - swW - 6;
        int swY = y + (h - swH) / 2;
        int track = 0xFF000000 | Gfx.lerp(0x3A3A42, Gfx.accent(), anim);
        Gfx.roundRect(m, swX, swY, swW, swH, swH / 2, track);
        int knobX = swX + 2 + (int) ((swW - swH + 2) * anim);
        int knobR = (swH - 4);
        Gfx.roundRect(m, knobX, swY + 2, knobR, knobR, knobR / 2, 0xFFFFFFFF);

        var tr = MinecraftClient.getInstance().textRenderer;
        int maxLabelW = swX - x - 10;
        String shown = label;
        while (tr.getWidth(shown) > maxLabelW && shown.length() > 1) {
            shown = shown.substring(0, shown.length() - 1);
        }
        int tc = Gfx.lerp(0xC9C9CF, 0xFFFFFF, anim * 0.6f);
        tr.drawWithShadow(m, shown, x + 6, y + (h - 8) / 2f, 0xFF000000 | tc);
    }
}
