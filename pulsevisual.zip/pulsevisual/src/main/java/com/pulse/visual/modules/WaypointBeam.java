package com.pulse.visual.modules;

import com.pulse.visual.Module;
import com.pulse.visual.Waypoints;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;

/** A tall beam of particles at each saved waypoint within 64 blocks, like a beacon. */
public class WaypointBeam extends Module {
    public WaypointBeam() { super("Waypoint Beam", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        for (Waypoints.Point p : Waypoints.all()) {
            double dx = p.x - mc.player.getX();
            double dz = p.z - mc.player.getZ();
            if (dx * dx + dz * dz > 64.0 * 64.0) continue;
            for (int i = 0; i < 20; i++) {
                mc.world.addParticle(ParticleTypes.WITCH, p.x + 0.5, p.y + i * 1.5, p.z + 0.5, 0, 0, 0);
            }
        }
    }
}
