package com.pulse.visual.modules;

import com.pulse.visual.Module;
import com.pulse.visual.Stats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class FpsCps extends Module {
    public FpsCps() { super("FPS / CPS", "Info", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        String s = "FPS " + Stats.fps() + "   CPS " + Stats.leftCps() + " | " + Stats.rightCps();
        int x = (mc.getWindow().getScaledWidth() - mc.textRenderer.getWidth(s)) / 2;
        mc.textRenderer.drawWithShadow(m, s, x, 15, 0xCCCCCC);
    }
}
