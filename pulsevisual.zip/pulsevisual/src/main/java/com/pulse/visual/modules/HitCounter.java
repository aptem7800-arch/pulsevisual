package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

public class HitCounter extends Module {
    private int hits, combo;
    private long lastHit;

    public HitCounter() { super("Hit Counter", true); }

    @Override
    public void onAttack(Entity e) {
        hits++;
        combo++;
        lastHit = System.currentTimeMillis();
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (combo > 0 && System.currentTimeMillis() - lastHit > 3000) combo = 0;
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        String s = "Hits: " + hits + "  Combo: " + combo;
        int x = (mc.getWindow().getScaledWidth() - mc.textRenderer.getWidth(s)) / 2;
        mc.textRenderer.drawWithShadow(m, s, x, 4, 0xFFFFFF);
    }
}
