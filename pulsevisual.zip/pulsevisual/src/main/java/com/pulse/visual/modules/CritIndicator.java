package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

public class CritIndicator extends Module {
    public CritIndicator() { super("Crit Indicator", "Info", true); }

    public static boolean isCrit(PlayerEntity p) {
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting()
                && p.getAttackCooldownProgress(0.5f) > 0.9f;
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        if (!isCrit(mc.player)) return;
        String s = "CRIT READY";
        int x = (mc.getWindow().getScaledWidth() - mc.textRenderer.getWidth(s)) / 2;
        mc.textRenderer.drawWithShadow(m, s, x, mc.getWindow().getScaledHeight() / 2 - 30, 0x55FF55);
    }
}
