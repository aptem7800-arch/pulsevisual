package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class AlertHud extends Module {
    public AlertHud() { super("HP Alert", "Visual", true); }

    private void centered(MatrixStack m, MinecraftClient mc, String s, int y, int color) {
        int x = (mc.getWindow().getScaledWidth() - mc.textRenderer.getWidth(s)) / 2;
        mc.textRenderer.drawWithShadow(m, s, x, y, color);
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        long now = System.currentTimeMillis();
        boolean blink = (now / 300) % 2 == 0;

        float hp = mc.player.getHealth();
        if (hp > 0f && hp <= 6f) {
            int a = 30 + (int) (40 * Math.abs(Math.sin(now / 250.0)));
            DrawableHelper.fill(m, 0, 0, w, h, (a << 24) | 0xFF0000);
            if (blink) centered(m, mc, "LOW HP", 40, 0xFF5555);
        }

        boolean armorLow = false;
        for (ItemStack s : mc.player.getInventory().armor) {
            if (!s.isEmpty() && s.isDamageable()
                    && (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage() < 15) {
                armorLow = true;
            }
        }
        if (armorLow && blink) centered(m, mc, "ARMOR LOW", 52, 0xFFAA00);
    }
}
