package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Sharp purple hitbox lines. Drawn with normal depth testing, so nothing shows through walls. */
public class PurpleHitbox extends Module {
    public PurpleHitbox() { super("Purple Hitbox", "Visual", false); }

    @Override
    public void renderWorld(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || ctx.consumers() == null) return;

        VertexConsumerProvider vcp = ctx.consumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        MatrixStack ms = ctx.matrixStack();
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickDelta();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc.player) continue;
            if (mc.player.squaredDistanceTo(e) > 64.0 * 64.0) continue;
            Vec3d p = e.getLerpedPos(td);
            Box b = e.getBoundingBox()
                    .offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ())
                    .offset(-cam.x, -cam.y, -cam.z);
            WorldRenderer.drawBox(ms, vc, b, 0.72f, 0.30f, 1.0f, 1.0f);
        }
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLines());
    }
}
