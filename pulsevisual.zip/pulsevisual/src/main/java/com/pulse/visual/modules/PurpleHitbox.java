package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Sharp hitbox lines, colour chosen by you. Drawn with normal depth testing, so nothing shows through walls. */
public class PurpleHitbox extends Module {
    /** 0 = follows the menu theme colour, 1 = rainbow, 2 = plain white. */
    public static int colorMode = 0;
    public static final String[] MODE_NAMES = {"Theme", "Rainbow", "White"};

    public PurpleHitbox() { super("Hitbox", "Visual", false); }

    private int currentColor() {
        switch (Math.max(0, Math.min(2, colorMode))) {
            case 1: {
                float hue = (System.currentTimeMillis() % 3000L) / 3000f;
                return java.awt.Color.HSBtoRGB(hue, 0.8f, 1.0f) & 0xFFFFFF;
            }
            case 2:
                return 0xFFFFFF;
            default:
                return Gfx.accent();
        }
    }

    @Override
    public void renderWorld(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || ctx.consumers() == null) return;

        VertexConsumerProvider vcp = ctx.consumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        MatrixStack ms = ctx.matrixStack();
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickDelta();
        int c = currentColor();
        float cr = ((c >> 16) & 255) / 255f, cg = ((c >> 8) & 255) / 255f, cb = (c & 255) / 255f;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc.player) continue;
            if (mc.player.squaredDistanceTo(e) > 64.0 * 64.0) continue;
            Vec3d p = e.getLerpedPos(td);
            Box b = e.getBoundingBox()
                    .offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ())
                    .offset(-cam.x, -cam.y, -cam.z);
            WorldRenderer.drawBox(ms, vc, b, cr, cg, cb, 1.0f);
        }
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLines());
    }
}
