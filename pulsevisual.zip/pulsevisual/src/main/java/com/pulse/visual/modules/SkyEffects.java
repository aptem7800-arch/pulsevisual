package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.concurrent.ThreadLocalRandom;

/** A coloured haze of particles drifting around the sky above you. Not a real re-textured sky -
 *  that needs a deeper render hook than is safe to add without being able to compile and test it -
 *  but it gives a real, visible colour mood: Green, Purple, Rainbow, Dark or a falling Starfall. */
public class SkyEffects extends Module {
    public static int preset = 0;
    public static final String[] PRESET_NAMES = {"Green", "Purple", "Rainbow", "Dark", "Starfall"};

    public SkyEffects() { super("Sky Effects", "Visual", false); }

    private ParticleEffect particleFor(int p, ThreadLocalRandom r) {
        switch (p) {
            case 0: return ParticleTypes.HAPPY_VILLAGER;
            case 1: return ParticleTypes.WITCH;
            case 2: {
                ParticleEffect[] palette = {
                        ParticleTypes.WITCH, ParticleTypes.HAPPY_VILLAGER,
                        ParticleTypes.FLAME, ParticleTypes.END_ROD, ParticleTypes.SOUL
                };
                return palette[r.nextInt(palette.length)];
            }
            case 3: return ParticleTypes.SMOKE;
            default: return ParticleTypes.END_ROD; // Starfall
        }
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int p = Math.max(0, Math.min(PRESET_NAMES.length - 1, preset));
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();

        if (p == 4) {
            // Starfall: streaks falling from high above, within a wide column around the player
            for (int i = 0; i < 2; i++) {
                double x = px + (r.nextDouble() - 0.5) * 40;
                double z = pz + (r.nextDouble() - 0.5) * 40;
                double y = py + 25 + r.nextDouble() * 15;
                mc.world.addParticle(ParticleTypes.END_ROD, x, y, z, 0, -0.35, 0);
            }
            return;
        }

        for (int i = 0; i < 3; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            double dist = 14 + r.nextDouble() * 10;
            double x = px + Math.cos(a) * dist;
            double z = pz + Math.sin(a) * dist;
            double y = py + 10 + r.nextDouble() * 12;
            mc.world.addParticle(particleFor(p, r), x, y, z, 0, 0.01, 0);
        }
    }
}
