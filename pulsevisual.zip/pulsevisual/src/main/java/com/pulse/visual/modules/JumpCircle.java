package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

/** On every jump a swirling purple ring expands from your feet and lingers for about a second. */
public class JumpCircle extends Module {
    private boolean wasOnGround = true;
    private double cx, cy, cz;
    private int age = -1;

    public JumpCircle() { super("Jump Circle", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (mc.world == null) return;
        boolean ground = p.isOnGround();
        if (wasOnGround && !ground && p.getVelocity().y > 0.1) {
            cx = p.getX();
            cy = p.getY() + 0.05;
            cz = p.getZ();
            age = 0;
        }
        wasOnGround = ground;

        if (age >= 0) {
            double r = 0.4 + age * 0.07;
            int n = 18;
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2.0 * i / n + age * 0.2;
                mc.world.addParticle(i % 3 == 0 ? ParticleTypes.DRAGON_BREATH : ParticleTypes.WITCH,
                        cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 0, 0.01, 0);
            }
            age++;
            if (age > 14) age = -1;
        }
    }
}
