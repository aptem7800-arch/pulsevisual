package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

/** A purple ring of particles expands from your feet every time you jump. */
public class JumpCircle extends Module {
    private boolean wasOnGround = true;

    public JumpCircle() { super("Jump Circle", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        boolean ground = p.isOnGround();
        if (wasOnGround && !ground && p.getVelocity().y > 0.1 && mc.world != null) {
            for (int i = 0; i < 20; i++) {
                double a = Math.PI * 2.0 * i / 20.0;
                mc.world.addParticle(ParticleTypes.WITCH,
                        p.getX() + Math.cos(a) * 0.9, p.getY() + 0.05, p.getZ() + Math.sin(a) * 0.9,
                        Math.cos(a) * 0.05, 0.02, Math.sin(a) * 0.05);
            }
        }
        wasOnGround = ground;
    }
}
