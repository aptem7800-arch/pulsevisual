package com.pulse.visual;

import java.util.ArrayList;
import java.util.List;

/** Named locations the player saves with /waypoint add, shown by WaypointHud / WaypointBeam. */
public final class Waypoints {
    public static final class Point {
        public final String name;
        public final double x, y, z;
        public Point(String name, double x, double y, double z) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private static final List<Point> POINTS = new ArrayList<>();

    private Waypoints() {}

    public static List<Point> all() { return POINTS; }

    public static void add(String name, double x, double y, double z) {
        POINTS.removeIf(p -> p.name.equalsIgnoreCase(name));
        POINTS.add(new Point(name, x, y, z));
        PulseMod.MODULES.save();
    }

    public static boolean remove(String name) {
        boolean removed = POINTS.removeIf(p -> p.name.equalsIgnoreCase(name));
        if (removed) PulseMod.MODULES.save();
        return removed;
    }

    public static String serialize() {
        StringBuilder sb = new StringBuilder();
        for (Point p : POINTS) {
            if (sb.length() > 0) sb.append('|');
            sb.append(p.name.replace(':', '_').replace('|', '_'))
                    .append(':').append(p.x).append(':').append(p.y).append(':').append(p.z);
        }
        return sb.toString();
    }

    public static void deserialize(String s) {
        POINTS.clear();
        if (s == null || s.isEmpty()) return;
        for (String part : s.split("\\|")) {
            String[] f = part.split(":");
            if (f.length != 4) continue;
            try {
                POINTS.add(new Point(f[0], Double.parseDouble(f[1]), Double.parseDouble(f[2]), Double.parseDouble(f[3])));
            } catch (NumberFormatException ignored) {}
        }
    }
}
