package com.pulse.visual;

import com.pulse.visual.modules.AimAssist;
import com.pulse.visual.modules.BlockOutline;
import com.pulse.visual.modules.CustomCrosshair;
import com.pulse.visual.HudScale;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModuleScreen extends Screen {
    private static int tab = 0;
    private final List<GlowButton> buttons = new ArrayList<>();
    private final List<GlowSlider> sliders = new ArrayList<>();
    private int px, py, pw, ph;

    private long opened;

    public ModuleScreen() {
        super(Text.literal("PULSE VISUAL"));
        this.opened = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        buttons.clear();
        sliders.clear();
        pw = Math.min(width - 20, Math.max(330, width * 3 / 5));
        ph = Math.min(height - 10, Math.max(180, height * 2 / 3));
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        String[] cats = ModuleManager.CATEGORIES;
        for (int i = 0; i < cats.length; i++) {
            final int idx = i;
            buttons.add(new GlowButton(px + 8, py + 28 + i * 24, 64, 20, cats[i],
                    () -> idx == tab,
                    () -> { tab = idx; client.setScreen(new ModuleScreen()); }));
        }

        int cx = px + 80;
        int cw = pw - 88;
        int bw = (cw - 8) / 2;
        int col = 0, row = 0;
        for (Module mod : PulseMod.MODULES.all()) {
            if (!mod.category.equals(cats[tab])) continue;
            int x = cx + col * (bw + 8);
            int y = py + 28 + row * 24;
            buttons.add(new GlowButton(x, y, bw, 20, mod.name,
                    () -> mod.enabled,
                    () -> { mod.enabled = !mod.enabled; PulseMod.MODULES.save(); }));
            col++;
            if (col == 2) { col = 0; row++; }
        }

        if (cats[tab].equals("Settings")) {
            if (col != 0) row++;
            int y = py + 28 + row * 24;
            buttons.add(new GlowButton(cx, y, bw, 20, "Theme: " + Theme.name(),
                    () -> true,
                    () -> { Theme.next(); PulseMod.MODULES.save(); }));
            row++;
            sliders.add(new GlowSlider(cx, py + 28 + row * 24, cw, 20,
                    "HUD Scale", "%", 50, 150,
                    () -> HudScale.percent, v -> HudScale.percent = v));
            row++;
            sliders.add(new GlowSlider(cx, py + 28 + row * 24, cw, 20,
                    "Crosshair Size", "px", 4, 16,
                    () -> CustomCrosshair.size, v -> CustomCrosshair.size = v));
            row++;
            buttons.add(new GlowButton(cx, py + 28 + row * 24, cw, 20,
                    "Outline Color: " + BlockOutline.MODE_NAMES[BlockOutline.colorMode],
                    () -> true,
                    () -> { BlockOutline.colorMode = (BlockOutline.colorMode + 1) % 3; PulseMod.MODULES.save(); }));
        }

        buttons.add(new GlowButton(px + pw - 24, py + 4, 16, 16, "x", () -> false, this::close));

        if (cats[tab].equals("Auto")) {
            if (col != 0) row++;
            int y = py + 28 + row * 24;
            buttons.add(new GlowButton(cx, y, bw, 20, "Aim: Hostile",
                    () -> AimAssist.hostile,
                    () -> { AimAssist.hostile = !AimAssist.hostile; PulseMod.MODULES.save(); }));
            buttons.add(new GlowButton(cx + bw + 8, y, bw, 20, "Aim: Passive",
                    () -> AimAssist.passive,
                    () -> { AimAssist.passive = !AimAssist.passive; PulseMod.MODULES.save(); }));
            row++;
            sliders.add(new GlowSlider(cx, py + 28 + row * 24, cw, 20,
                    "Aim Smoothness", "  (0 snap, 10 smooth)", 0, 10,
                    () -> AimAssist.smoothness, v -> AimAssist.smoothness = v));
            row++;
            sliders.add(new GlowSlider(cx, py + 28 + row * 24, cw, 20,
                    "Aim Range", " blocks", 4, 6,
                    () -> AimAssist.range, v -> AimAssist.range = v));
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_M) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (GlowButton b : buttons) {
                if (b.click(mouseX, mouseY)) return true;
            }
            for (GlowSlider s : sliders) {
                if (s.mouseClicked(mouseX, mouseY)) return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        for (GlowSlider s : sliders) s.mouseDragged(mouseX);
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (GlowSlider s : sliders) s.mouseReleased();
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        float pulse = (float) (0.5 + 0.5 * Math.sin((System.currentTimeMillis() - opened) / 420.0));
        int borderColor = 0xFF000000 | Gfx.lerp(Gfx.accentDark(), Gfx.accent(), pulse * 0.6f);
        Gfx.roundRect(m, px - 3, py - 3, pw + 6, ph + 6, 9, (40 << 24) | Gfx.accent());
        Gfx.roundBorder(m, px, py, pw, ph, 6, borderColor, 0xFF0A0A0D);
        Gfx.gradientLine(m, px + 8, py + 22, pw - 16);
        fill(m, px + 76, py + 28, px + 77, py + ph - 26, 0xFF000000 | Gfx.lerp(0x000000, Gfx.accentDark(), 0.6f));
        Gfx.gradientLine(m, px + 8, py + ph - 20, pw - 16);

        textRenderer.drawWithShadow(m, "PULSE VISUAL", px + 8, py + 8, 0xFF000000 | Gfx.accent());
        String ver = "v" + FabricLoader.getInstance().getModContainer("pulsevisual")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
        textRenderer.drawWithShadow(m, ver, px + pw - 8 - textRenderer.getWidth(ver), py + 8, 0xFF8E8E9A);
        drawCenteredTextWithShadow(m, textRenderer, "Created by Glazik + Claude", width / 2, py + ph - 14, 0xFF000000 | Gfx.accent());

        for (GlowButton b : buttons) b.render(m, mouseX, mouseY);
        for (GlowSlider s : sliders) s.render(m);
    }
}
