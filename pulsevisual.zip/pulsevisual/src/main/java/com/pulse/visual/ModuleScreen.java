package com.pulse.visual;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class ModuleScreen extends Screen {
    public ModuleScreen() {
        super(Text.literal("PulseVisual"));
    }

    @Override
    protected void init() {
        int y = 40;
        for (Module mod : PulseMod.MODULES.all()) {
            addDrawableChild(ButtonWidget.builder(label(mod), b -> {
                mod.enabled = !mod.enabled;
                b.setMessage(label(mod));
            }).dimensions(width / 2 - 80, y, 160, 20).build());
            y += 24;
        }
    }

    private Text label(Module m) {
        return Text.literal(m.name + ": " + (m.enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        renderBackground(matrices);
        drawCenteredTextWithShadow(matrices, textRenderer, title, width / 2, 15, 0xFFFFFF);
        super.render(matrices, mouseX, mouseY, delta);
    }
}
