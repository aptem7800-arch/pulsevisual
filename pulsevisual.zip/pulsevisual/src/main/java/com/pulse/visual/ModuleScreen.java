package com.pulse.visual;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModuleScreen extends Screen {
    private static int tab = 0;
    private final List<GlowButton> buttons = new ArrayList<>();
    private GlowSlider slider;
    private int px, py, pw, ph;

    public ModuleScreen() {
        super(Text.literal("PULSE VISUAL"));
    }

    @Override
    protected void init() {
        buttons.clear();
        slider = null;
        pw = Math.min(width - 20, Math.max(330, width * 3 / 5));
        ph = Math.min(height - 10, Math.max(180, height * 2 / 3));
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        String[] cats = ModuleManager.CATEGORIES;
        for (int i = 0; i < cats.length; i++) {
            final int idx = i;
            buttons.add(new GlowButton(px + 8, py + 28 + i * 24, 64, 20, cats[i],
                    () -> idx == tab,
                    () -> { tab = idx; client.setScreen(new ModuleScreen()); }));
        }

        int cx = px + 80;
        int cw = pw - 88;
        int bw = (cw - 8) / 2;
        int col = 0, row = 0;
        for (Module mod : PulseMod.MODULES.all()) {
            if (!mod.category.equals(cats[tab])) continue;
            int x = cx + col * (bw + 8);
            int y = py + 28 + row * 24;
            buttons.add(new GlowButton(x, y, bw, 20, mod.name,
                    () -> mod.enabled,
                    () -> { mod.enabled = !mod.enabled; PulseMod.MODULES.save(); }));
            col++;
            if (col == 2) { col = 0; row++; }
        }

        if (cats[tab].equals("Auto")) {
            if (col != 0) row++;
            slider = new GlowSlider(cx, py + 28 + row * 24, cw, 20);
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_M) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (GlowButton b : buttons) {
                if (b.click(mouseX, mouseY)) return true;
            }
            if (slider != null && slider.mouseClicked(mouseX, mouseY)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (slider != null) slider.mouseDragged(mouseX);
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (slider != null) slider.mouseReleased();
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void render(MatrixStack m, int mouseX, int mouseY, float delta) {
        Gfx.roundBorder(m, px, py, pw, ph, 6, 0xFF000000 | Gfx.PURPLE_DARK, 0xFF0A0A0D);
        Gfx.gradientLine(m, px + 8, py + 22, pw - 16);
        fill(m, px + 76, py + 28, px + 77, py + ph - 26, 0xFF3A1F7A);
        Gfx.gradientLine(m, px + 8, py + ph - 20, pw - 16);

        textRenderer.drawWithShadow(m, "PULSE VISUAL", px + 8, py + 8, 0xFFB84DFF);
        String ver = "v" + FabricLoader.getInstance().getModContainer("pulsevisual")
                .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
        textRenderer.drawWithShadow(m, ver, px + pw - 8 - textRenderer.getWidth(ver), py + 8, 0xFF8E8E9A);
        drawCenteredTextWithShadow(m, textRenderer, "Created by Glazik + Claude", width / 2, py + ph - 14, 0xFFB84DFF);

        for (GlowButton b : buttons) b.render(m, mouseX, mouseY);
        if (slider != null) slider.render(m);
    }
}
