package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Turns the camera toward the nearest mob (never players) while the attack button is held. */
public class AimAssist extends Module {
    private static final float RANGE = 6.0f;
    /** 0 = instant snap, 10 = maximum smooth. */
    public static int smoothness = 5;

    public AimAssist() { super("Aim Assist", "Auto", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e == mc.player || e instanceof PlayerEntity || e instanceof ArmorStandEntity) continue;
            if (!le.isAlive()) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d > RANGE * RANGE || d >= bestDist) continue;
            if (!mc.player.canSee(e)) continue;
            best = le;
            bestDist = d;
        }
        if (best == null) return;

        float smooth = (float) Math.pow(0.04, Math.max(0, Math.min(10, smoothness)) / 10.0);
        Vec3d eye = mc.player.getEyePos();
        Vec3d tp = best.getBoundingBox().getCenter();
        double dx = tp.x - eye.x, dy = tp.y - eye.y, dz = tp.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));

        float ny = mc.player.getYaw() + MathHelper.wrapDegrees(yaw - mc.player.getYaw()) * smooth;
        float np = mc.player.getPitch() + (pitch - mc.player.getPitch()) * smooth;
        mc.player.setYaw(ny);
        mc.player.setPitch(MathHelper.clamp(np, -90f, 90f));
    }
}
