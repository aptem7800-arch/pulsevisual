package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Automatically turns the camera toward the nearest mob (never players). No button needed. */
public class AimAssist extends Module {
    /** 0 = instant snap, 10 = maximum smooth. */
    public static int smoothness = 5;
    /** Search radius in blocks (4 to 6). */
    public static int range = 6;
    /** Which kinds of mobs to follow. */
    public static boolean hostile = true;
    public static boolean passive = true;

    public AimAssist() { super("Aim Assist", "Auto", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.currentScreen != null) return;

        double r = Math.max(4, Math.min(6, range));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e == mc.player || e instanceof PlayerEntity || e instanceof ArmorStandEntity) continue;
            if (!le.isAlive()) continue;
            if (e instanceof Monster ? !hostile : !passive) continue;
            double d = mc.player.squaredDistanceTo(e);
            if (d > r * r || d >= bestDist) continue;
            if (!mc.player.canSee(e)) continue;
            best = le;
            bestDist = d;
        }
        if (best == null) return;

        float smooth = (float) Math.pow(0.04, Math.max(0, Math.min(10, smoothness)) / 10.0);
        Vec3d eye = mc.player.getEyePos();
        Vec3d tp = best.getBoundingBox().getCenter();
        double dx = tp.x - eye.x, dy = tp.y - eye.y, dz = tp.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));

        float ny = mc.player.getYaw() + MathHelper.wrapDegrees(yaw - mc.player.getYaw()) * smooth;
        float np = mc.player.getPitch() + (pitch - mc.player.getPitch()) * smooth;
        mc.player.setYaw(ny);
        mc.player.setPitch(MathHelper.clamp(np, -90f, 90f));
    }
}
