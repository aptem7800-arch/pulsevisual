package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

/** Auto-attacks the nearest mob in reach. Mobs only: never players, tamed pets or villagers. */
public class MobAura extends Module {
    private static final float REACH = 3.0f;

    public MobAura() { super("Mob Aura", "Auto", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < 0.95f) return;

        LivingEntity best = null;
        float bestDist = Float.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e == mc.player || e instanceof PlayerEntity || e instanceof ArmorStandEntity) continue;
            if (e instanceof MerchantEntity) continue;
            if (e instanceof TameableEntity t && t.isTamed()) continue;
            if (!le.isAlive()) continue;
            float d = mc.player.distanceTo(e);
            if (d > REACH || d >= bestDist) continue;
            if (!mc.player.canSee(e)) continue;
            best = le;
            bestDist = d;
        }
        if (best == null) return;
        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
