package com.pulse.visual;

import com.pulse.visual.modules.AimAssist;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

/** Aim smoothness: 0 = instant snap, 10 = maximum smooth. Glows purple while dragged. */
public class GlowSlider {
    private final int x, y, w, h;
    private boolean dragging;
    private float glow;

    public GlowSlider(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    private void setFromMouse(double mx) {
        double v = Math.max(0.0, Math.min(1.0, (mx - (x + 1)) / (double) (w - 2)));
        AimAssist.smoothness = (int) Math.round(v * 10.0);
    }

    public boolean mouseClicked(double mx, double my) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            dragging = true;
            setFromMouse(mx);
            return true;
        }
        return false;
    }

    public void mouseDragged(double mx) {
        if (dragging) setFromMouse(mx);
    }

    public void mouseReleased() {
        if (dragging) {
            dragging = false;
            PulseMod.MODULES.save();
        }
    }

    public void render(MatrixStack m) {
        glow += ((dragging ? 1f : 0f) - glow) * 0.25f;
        double value = AimAssist.smoothness / 10.0;
        int filled = (int) ((w - 2) * value);
        int thumbX = x + 1 + filled;

        DrawableHelper.fill(m, x, y, x + w, y + h, 0xFF121217);
        if (filled > 0) {
            DrawableHelper.fillGradient(m, x + 1, y + 1, x + 1 + filled, y + h - 1, 0xFF5B21C9, 0xFFB84DFF);
        }
        if (glow > 0.05f) {
            int a = (int) (110 * glow);
            DrawableHelper.fill(m, thumbX - 4, y - 2, thumbX + 4, y + h + 2, (a << 24) | Gfx.PURPLE);
        }
        DrawableHelper.fill(m, thumbX - 1, y, thumbX + 1, y + h, 0xFFFFFFFF);
        Gfx.border(m, x, y, w, h, 0xFF000000 | Gfx.lerp(0xFFFFFF, Gfx.PURPLE, glow));

        var tr = MinecraftClient.getInstance().textRenderer;
        String s = "Aim Smoothness " + AimAssist.smoothness + "  (0 snap, 10 smooth)";
        tr.drawWithShadow(m, s, x + (w - tr.getWidth(s)) / 2f, y + (h - 8) / 2f, 0xFFFFFFFF);
    }
}
