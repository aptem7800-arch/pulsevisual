package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Rounded integer slider that glows purple while dragged. */
public class GlowSlider {
    private final int x, y, w, h, min, max;
    private final String label, hint;
    private final IntSupplier getter;
    private final IntConsumer setter;
    private boolean dragging;
    private float glow;

    public GlowSlider(int x, int y, int w, int h, String label, String hint,
                      int min, int max, IntSupplier getter, IntConsumer setter) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.hint = hint;
        this.min = min;
        this.max = max;
        this.getter = getter;
        this.setter = setter;
    }

    private void setFromMouse(double mx) {
        double v = Math.max(0.0, Math.min(1.0, (mx - (x + 2)) / (double) (w - 4)));
        setter.accept(min + (int) Math.round(v * (max - min)));
    }

    public boolean mouseClicked(double mx, double my) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            dragging = true;
            setFromMouse(mx);
            return true;
        }
        return false;
    }

    public void mouseDragged(double mx) {
        if (dragging) setFromMouse(mx);
    }

    public void mouseReleased() {
        if (dragging) {
            dragging = false;
            PulseMod.MODULES.save();
        }
    }

    public void render(MatrixStack m) {
        glow += ((dragging ? 1f : 0f) - glow) * 0.25f;
        int val = getter.getAsInt();
        double value = (val - min) / (double) Math.max(1, max - min);
        int filled = (int) ((w - 4) * value);
        int thumbX = x + 2 + filled;

        if (glow > 0.05f) {
            int a = (int) (70 * glow);
            Gfx.roundRect(m, x - 2, y - 2, w + 4, h + 4, 6, (a << 24) | Gfx.accent());
        }
        Gfx.roundBorder(m, x, y, w, h, 4, 0xFF000000 | Gfx.lerp(0xFFFFFF, Gfx.accent(), glow), 0xFF121217);
        for (int i = 0; i < filled; i += 2) {
            int c = 0xFF000000 | Gfx.lerp(0x5B21C9, Gfx.accent(), (float) i / Math.max(1, w - 4));
            DrawableHelper.fill(m, x + 2 + i, y + 2, Math.min(x + 2 + i + 2, x + 2 + filled), y + h - 2, c);
        }
        DrawableHelper.fill(m, thumbX - 1, y + 1, thumbX + 1, y + h - 1, 0xFFFFFFFF);

        var tr = MinecraftClient.getInstance().textRenderer;
        String s = label + " " + val + hint;
        tr.drawWithShadow(m, s, x + (w - tr.getWidth(s)) / 2f, y + (h - 8) / 2f, 0xFFFFFFFF);
    }
}
