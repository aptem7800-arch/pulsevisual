package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/** Purple particles streaming from the centre of the current target, burst on hit, chime on crit. */
public class PurpleParticles extends Module {
    private LivingEntity focus;

    public PurpleParticles() { super("Particles", "Visual", true); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) focus = le;
        LivingEntity t = focus;
        if (t == null) return;
        if (t.isRemoved() || !t.isAlive() || mc.player.distanceTo(t) > 5f) {
            focus = null;
            return;
        }
        spawn(mc, t, 2, 0.08);
    }

    @Override
    public void onAttack(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        if (e instanceof LivingEntity le) focus = le;
        boolean crit = CritIndicator.isCrit(mc.player);
        spawn(mc, e, 10, 0.25, crit);
        if (crit) play(mc, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME);
    }

    private void spawn(MinecraftClient mc, Entity e, int n, double speed) {
        spawn(mc, e, n, speed, false);
    }

    private void spawn(MinecraftClient mc, Entity e, int n, double speed, boolean crit) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Box b = e.getBoundingBox();
        Vec3d c = b.getCenter();
        double w = b.getXLength() * 0.4, h = b.getYLength() * 0.4;
        for (int i = 0; i < n; i++) {
            // on a critical hit the usual purple swirl turns red, like a damage flash
            var type = crit ? ParticleTypes.DAMAGE_INDICATOR : (i % 3 == 0 ? ParticleTypes.DRAGON_BREATH : ParticleTypes.WITCH);
            mc.world.addParticle(type,
                    c.x + (r.nextDouble() - 0.5) * w, c.y + (r.nextDouble() - 0.5) * h, c.z + (r.nextDouble() - 0.5) * w,
                    (r.nextDouble() - 0.5) * speed, r.nextDouble() * speed, (r.nextDouble() - 0.5) * speed);
        }
    }
}
