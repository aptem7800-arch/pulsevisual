package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;

/** Holding the use key (right click / secondary) zooms the FOV in, like a spyglass. */
public class Zoom extends Module {
    private boolean zooming;
    private double savedFov = -1;

    public Zoom() { super("Zoom", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        boolean held = mc.options.useKey.isPressed() && mc.currentScreen == null;
        if (held && !zooming) {
            savedFov = mc.options.getFov().getValue();
            zooming = true;
        } else if (!held && zooming) {
            if (savedFov >= 0) mc.options.getFov().setValue((int) savedFov);
            zooming = false;
            savedFov = -1;
        }
        if (zooming) mc.options.getFov().setValue(15);
    }

    @Override
    public void update(MinecraftClient mc) {
        if (!enabled && zooming) {
            if (savedFov >= 0) mc.options.getFov().setValue((int) savedFov);
            zooming = false;
            savedFov = -1;
        }
    }
}
