package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;

import java.util.Locale;

public class TargetHud extends Module {
    private LivingEntity target;
    private int lastTotems = -1;
    private boolean lowPlayed;

    public TargetHud() { super("Target HUD", "HUD", true); }

    private void setTarget(LivingEntity t) {
        if (t != target) {
            target = t;
            lastTotems = -1;
            lowPlayed = false;
        }
    }

    private static int totems(LivingEntity t) {
        int c = 0;
        ItemStack a = t.getMainHandStack();
        ItemStack b = t.getOffHandStack();
        if (a.isOf(Items.TOTEM_OF_UNDYING)) c += a.getCount();
        if (b.isOf(Items.TOTEM_OF_UNDYING)) c += b.getCount();
        return c;
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) setTarget(le);
        LivingEntity t = target;
        if (t == null) return;
        if (t.isRemoved() || !t.isAlive() || mc.player.distanceTo(t) > 5f) {
            target = null;
            return;
        }
        if (t instanceof PlayerEntity) {
            if (!lowPlayed && t.getHealth() <= 6f) {
                lowPlayed = true;
                play(mc, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP);
            }
            int c = totems(t);
            if (lastTotems >= 0 && c < lastTotems) play(mc, SoundEvents.ITEM_TOTEM_USE);
            lastTotems = c;
        }
    }

    @Override
    public void onAttack(Entity e) {
        if (e instanceof LivingEntity le) setTarget(le);
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        LivingEntity t = target;
        if (t == null) return;
        boolean player = t instanceof PlayerEntity;
        int x = mc.getWindow().getScaledWidth() / 2 + 20;
        int y = mc.getWindow().getScaledHeight() / 2 + 20;
        int bh = player ? 62 : 34;
        float hp = t.getHealth();
        float max = Math.max(1f, t.getMaxHealth());
        float ratio = Math.max(0f, Math.min(1f, hp / max));

        DrawableHelper.fill(m, x, y, x + 130, y + bh, 0x90000000);
        mc.textRenderer.drawWithShadow(m, t.getName().getString(), x + 4, y + 3, 0xFFFFFF);
        DrawableHelper.fill(m, x + 4, y + 14, x + 126, y + 20, 0xFF333333);
        DrawableHelper.fill(m, x + 4, y + 14, x + 4 + (int) (122 * ratio), y + 20, 0xFF55FF55);
        mc.textRenderer.drawWithShadow(m,
                String.format(Locale.ROOT, "HP %.1f / %.1f", hp, max), x + 4, y + 23, 0xDDDDDD);

        if (player) {
            int sum = 0, n = 0;
            for (ItemStack s : t.getArmorItems()) {
                if (!s.isEmpty() && s.isDamageable()) {
                    sum += (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage();
                    n++;
                }
            }
            String armor = n == 0 ? "Armor: none" : "Armor: " + (sum / n) + "%  (" + t.getArmor() + ")";
            mc.textRenderer.drawWithShadow(m, armor, x + 4, y + 34, 0xAADDFF);
            mc.textRenderer.drawWithShadow(m, "Totems in hands: " + totems(t), x + 4, y + 46, 0xFFD54F);
        }
    }
}
