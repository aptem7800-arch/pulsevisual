package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class TargetHud extends Module {
    private LivingEntity target;
    private long targetTime;

    public TargetHud() { super("Target HUD", true); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.targetedEntity instanceof LivingEntity le) {
            target = le;
            targetTime = System.currentTimeMillis();
        }
    }

    @Override
    public void onAttack(Entity e) {
        if (e instanceof LivingEntity le) {
            target = le;
            targetTime = System.currentTimeMillis();
        }
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        LivingEntity t = target;
        if (t == null || t.isRemoved() || !t.isAlive()
                || System.currentTimeMillis() - targetTime > 4000) return;

        int x = mc.getWindow().getScaledWidth() / 2 + 20;
        int y = mc.getWindow().getScaledHeight() / 2 + 20;
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        float ratio = Math.min(1f, hp / max);
        int color = ratio > 0.6f ? 0xFF55FF55 : ratio > 0.3f ? 0xFFFFAA00 : 0xFFFF5555;

        DrawableHelper.fill(m, x, y, x + 120, y + 34, 0x90000000);
        mc.textRenderer.drawWithShadow(m, t.getName().getString(), x + 4, y + 3, 0xFFFFFF);
        DrawableHelper.fill(m, x + 4, y + 14, x + 116, y + 20, 0xFF333333);
        DrawableHelper.fill(m, x + 4, y + 14, x + 4 + (int) (112 * ratio), y + 20, color);
        mc.textRenderer.drawWithShadow(m,
                String.format("HP %.1f/%.1f  Armor %d", hp, max, t.getArmor()),
                x + 4, y + 23, 0xDDDDDD);
    }
}
