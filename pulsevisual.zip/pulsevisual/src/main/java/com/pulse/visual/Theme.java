package com.pulse.visual;

/** Accent colour used across the whole menu and HUD. Purple, Green, Blue or Red. */
public final class Theme {
    public static final String[] NAMES = {"Purple", "Green", "Blue", "Red"};
    private static final int[] COLORS = {0xB84DFF, 0x4DFF88, 0x4DA6FF, 0xFF4D4D};
    private static final int[] DARK = {0x6A2BD9, 0x1F9E4C, 0x1F5FA6, 0xA61F1F};

    public static int index = 0;

    private Theme() {}

    public static int accent() { return COLORS[Math.max(0, Math.min(COLORS.length - 1, index))]; }
    public static int dark() { return DARK[Math.max(0, Math.min(DARK.length - 1, index))]; }
    public static String name() { return NAMES[Math.max(0, Math.min(NAMES.length - 1, index))]; }
    public static void next() { index = (index + 1) % NAMES.length; }
}
