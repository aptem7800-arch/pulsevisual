package com.pulse.visual.modules;

import com.pulse.visual.Module;
import com.pulse.visual.Waypoints;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.util.Locale;

/** Lists saved /waypoint locations with live distance. Add one with: /waypoint add <name> */
public class WaypointHud extends Module {
    public WaypointHud() { super("Waypoint HUD", "HUD", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        var list = Waypoints.all();
        if (list.isEmpty()) return;
        int y = 92;
        for (Waypoints.Point p : list) {
            double dx = p.x - mc.player.getX();
            double dy = p.y - mc.player.getY();
            double dz = p.z - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            String s = String.format(Locale.ROOT, "%s: %.0fm", p.name, dist);
            mc.textRenderer.drawWithShadow(m, s, 4, y, 0xFFD54F);
            y += 10;
        }
    }
}
