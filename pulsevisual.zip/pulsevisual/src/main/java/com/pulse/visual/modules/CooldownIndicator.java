package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

public class CooldownIndicator extends Module {
    public CooldownIndicator() { super("Cooldown Bar", "Info", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        float p = mc.player.getAttackCooldownProgress(0f);
        if (p >= 1f) return;
        int cx = mc.getWindow().getScaledWidth() / 2;
        int y = mc.getWindow().getScaledHeight() / 2 + 10;
        DrawableHelper.fill(m, cx - 20, y, cx + 20, y + 3, 0x90000000);
        DrawableHelper.fill(m, cx - 20, y, cx - 20 + (int) (40 * p), y + 3, 0xFFFFFFFF);
    }
}
