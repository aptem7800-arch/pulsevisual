package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffectInstance;

public class PotionHud extends Module {
    public PotionHud() { super("Potion HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int y = 4;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            int sec = e.getDuration() / 20;
            String line = e.getEffectType().getName().getString()
                    + " " + (e.getAmplifier() + 1)
                    + "  " + (sec / 60) + ":" + String.format("%02d", sec % 60);
            int color = e.getEffectType().isBeneficial() ? 0x55FF55 : 0xFF5555;
            mc.textRenderer.drawWithShadow(m, line, 4, y, color);
            y += 11;
        }
    }
}
