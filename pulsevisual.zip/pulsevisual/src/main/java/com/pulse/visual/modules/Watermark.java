package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.Module;
import com.pulse.visual.Stats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class Watermark extends Module {
    public Watermark() { super("Watermark", "HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        String s = "PulseVisual | FPS: " + Stats.fps();
        mc.textRenderer.drawWithShadow(m, s, 4, mc.getWindow().getScaledHeight() - 10, 0xFF000000 | Gfx.accent());
    }
}
