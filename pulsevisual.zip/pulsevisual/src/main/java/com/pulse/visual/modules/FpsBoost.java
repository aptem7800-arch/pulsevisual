package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class FpsBoost extends Module {
    private boolean applied;
    private ParticlesMode oldParticles;
    private CloudRenderMode oldClouds;
    private GraphicsMode oldGraphics;
    private boolean oldShadows;

    public FpsBoost() { super("FPS Boost", "Visual", false); }

    @Override
    public void update(MinecraftClient mc) {
        if (mc.options == null || enabled == applied) return;
        if (enabled) {
            oldParticles = mc.options.getParticles().getValue();
            oldClouds = mc.options.getCloudRenderMode().getValue();
            oldGraphics = mc.options.getGraphicsMode().getValue();
            oldShadows = mc.options.getEntityShadows().getValue();
            mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
            mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
            mc.options.getEntityShadows().setValue(false);
        } else if (oldParticles != null) {
            mc.options.getParticles().setValue(oldParticles);
            mc.options.getCloudRenderMode().setValue(oldClouds);
            mc.options.getGraphicsMode().setValue(oldGraphics);
            mc.options.getEntityShadows().setValue(oldShadows);
        }
        applied = enabled;
    }
}
