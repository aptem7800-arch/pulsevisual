package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Themed outline around the block you are looking at, replacing the plain vanilla selection box. */
public class BlockOutline extends Module {
    /** 0 = follows the menu theme colour, 1 = rainbow, 2 = plain white. */
    public static int colorMode = 0;
    public static final String[] MODE_NAMES = {"Theme", "Rainbow", "White"};

    public BlockOutline() { super("Block Outline", "Visual", false); }

    private int currentColor() {
        switch (Math.max(0, Math.min(2, colorMode))) {
            case 1: {
                float hue = (System.currentTimeMillis() % 3000L) / 3000f;
                return java.awt.Color.HSBtoRGB(hue, 0.8f, 1.0f) & 0xFFFFFF;
            }
            case 2:
                return 0xFFFFFF;
            default:
                return Gfx.accent();
        }
    }

    @Override
    public void renderWorld(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
        if (mc.world == null || ctx.consumers() == null) return;

        BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
        if (mc.world.getBlockState(pos).isAir()) return;

        VertexConsumerProvider vcp = ctx.consumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        MatrixStack ms = ctx.matrixStack();
        Vec3d cam = ctx.camera().getPos();

        Box b = mc.world.getBlockState(pos).getOutlineShape(mc.world, pos).getBoundingBox()
                .offset(pos).offset(-cam.x, -cam.y, -cam.z).expand(0.002);
        int c = currentColor();
        WorldRenderer.drawBox(ms, vc, b, ((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 1.0f);
        if (vcp instanceof VertexConsumerProvider.Immediate imm) imm.draw(RenderLayer.getLines());
    }
}
