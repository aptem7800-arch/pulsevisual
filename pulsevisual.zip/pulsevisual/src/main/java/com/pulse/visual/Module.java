package com.pulse.visual;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvent;

public abstract class Module {
    public final String name;
    public final String category;
    public boolean enabled;

    protected Module(String name, String category, boolean enabled) {
        this.name = name;
        this.category = category;
        this.enabled = enabled;
    }

    /** Called every tick, even when the module is off. */
    public void update(MinecraftClient mc) {}
    /** Called every tick while the module is on. */
    public void tick(MinecraftClient mc) {}
    public void render(MatrixStack m, MinecraftClient mc) {}
    public void onAttack(Entity target) {}
    public void renderWorld(WorldRenderContext ctx) {}

    protected void play(MinecraftClient mc, SoundEvent sound) {
        mc.getSoundManager().play(PositionedSoundInstance.master(sound, 1.0f));
    }
}
