package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

public abstract class Module {
    public final String name;
    public boolean enabled;

    protected Module(String name, boolean enabled) {
        this.name = name;
        this.enabled = enabled;
    }

    public void tick(MinecraftClient mc) {}
    public void render(MatrixStack m, MinecraftClient mc) {}
    public void onAttack(Entity target) {}
}
