package com.pulse.visual;

import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

public final class Gfx {
    public static final int PURPLE = 0xB84DFF;
    public static final int PURPLE_DARK = 0x6A2BD9;

    private Gfx() {}

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    /** Filled rectangle with rounded corners. */
    public static void roundRect(MatrixStack m, int x, int y, int w, int h, int r, int argb) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            DrawableHelper.fill(m, x + inset, y + i, x + w - inset, y + i + 1, argb);
            DrawableHelper.fill(m, x + inset, y + h - 1 - i, x + w - inset, y + h - i, argb);
        }
        DrawableHelper.fill(m, x, y + r, x + w, y + h - r, argb);
    }

    /** Rounded rectangle with a 1px outline. Both colours should be opaque. */
    public static void roundBorder(MatrixStack m, int x, int y, int w, int h, int r, int borderArgb, int fillArgb) {
        roundRect(m, x, y, w, h, r, borderArgb);
        roundRect(m, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fillArgb);
    }

    /** Thin horizontal line with a purple gradient. */
    public static void gradientLine(MatrixStack m, int x, int y, int w) {
        int step = 4;
        for (int i = 0; i < w; i += step) {
            int c = lerp(0x7B2FFF, 0xE040FB, (float) i / Math.max(1, w));
            DrawableHelper.fill(m, x + i, y, Math.min(x + i + step, x + w), y + 1, 0xFF000000 | c);
        }
    }
}
