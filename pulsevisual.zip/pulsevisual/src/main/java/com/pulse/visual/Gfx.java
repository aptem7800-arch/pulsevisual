package com.pulse.visual;

import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

public final class Gfx {
    public static final int PURPLE = 0xB84DFF;
    public static final int PURPLE_DARK = 0x6A2BD9;

    private Gfx() {}

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    public static void border(MatrixStack m, int x, int y, int w, int h, int argb) {
        DrawableHelper.fill(m, x, y, x + w, y + 1, argb);
        DrawableHelper.fill(m, x, y + h - 1, x + w, y + h, argb);
        DrawableHelper.fill(m, x, y, x + 1, y + h, argb);
        DrawableHelper.fill(m, x + w - 1, y, x + w, y + h, argb);
    }

    /** Thin horizontal line with a purple gradient. */
    public static void gradientLine(MatrixStack m, int x, int y, int w) {
        int step = 4;
        for (int i = 0; i < w; i += step) {
            int c = lerp(0x7B2FFF, 0xE040FB, (float) i / Math.max(1, w));
            DrawableHelper.fill(m, x + i, y, Math.min(x + i + step, x + w), y + 1, 0xFF000000 | c);
        }
    }
}
