package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.concurrent.ThreadLocalRandom;

/** A visible ribbon of particles behind any moving player (you included), denser while sprinting
 *  or jumping. Colour is chosen on the Settings tab. */
public class Trails extends Module {
    public static int colorMode = 0;
    public static final String[] MODE_NAMES = {"Purple", "Green", "Red", "White", "Rainbow"};

    public Trails() { super("Trails", "Visual", false); }

    private ParticleEffect particleFor(ThreadLocalRandom r) {
        switch (Math.max(0, Math.min(4, colorMode))) {
            case 1: return ParticleTypes.HAPPY_VILLAGER;
            case 2: return ParticleTypes.DAMAGE_INDICATOR;
            case 3: return ParticleTypes.END_ROD;
            case 4: {
                ParticleEffect[] palette = {
                        ParticleTypes.PORTAL, ParticleTypes.HAPPY_VILLAGER,
                        ParticleTypes.DAMAGE_INDICATOR, ParticleTypes.END_ROD
                };
                return palette[r.nextInt(palette.length)];
            }
            default: return ParticleTypes.PORTAL;
        }
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (mc.player.squaredDistanceTo(p) > 32.0 * 32.0) continue;
            double dx = p.getX() - p.prevX, dy = p.getY() - p.prevY, dz = p.getZ() - p.prevZ;
            double speedSq = dx * dx + dy * dy + dz * dz;
            if (speedSq < 0.0009) continue; // standing still, no trail

            int n = speedSq > 0.01 ? 7 : 3; // more particles while sprinting or jumping
            for (int i = 0; i < n; i++) {
                double t = i / (double) n;
                double x = p.prevX + dx * t + (r.nextDouble() - 0.5) * 0.15;
                double y = p.prevY + dy * t + 0.1;
                double z = p.prevZ + dz * t + (r.nextDouble() - 0.5) * 0.15;
                mc.world.addParticle(particleFor(r), x, y, z,
                        (r.nextDouble() - 0.5) * 0.02, 0.02, (r.nextDouble() - 0.5) * 0.02);
            }
        }
    }
}
