package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

/** Purple particle trail behind moving players. */
public class Trails extends Module {
    public Trails() { super("Trails", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (mc.player.squaredDistanceTo(p) > 32.0 * 32.0) continue;
            double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
            if (dx * dx + dz * dz < 0.0025 && Math.abs(p.getY() - p.prevY) < 0.05) continue;
            mc.world.addParticle(ParticleTypes.WITCH, p.getX(), p.getY() + 0.15, p.getZ(), 0, 0.01, 0);
        }
    }
}
