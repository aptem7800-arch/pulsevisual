package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class InventoryHud extends Module {
    public InventoryHud() { super("Inventory HUD", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int x = 4;
        int y = mc.getWindow().getScaledHeight() / 2 - 30;
        DrawableHelper.fill(m, x - 2, y - 2, x + 164, y + 56, 0x90000000);
        for (int i = 0; i < 27; i++) {
            ItemStack s = mc.player.getInventory().main.get(9 + i);
            if (s.isEmpty()) continue;
            int ix = x + (i % 9) * 18;
            int iy = y + (i / 9) * 18;
            mc.getItemRenderer().renderGuiItemIcon(m, s, ix, iy);
            mc.getItemRenderer().renderGuiItemOverlay(m, mc.textRenderer, s, ix, iy);
        }
    }
}
