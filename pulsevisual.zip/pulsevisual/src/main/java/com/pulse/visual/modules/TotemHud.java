package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class TotemHud extends Module {
    private static final ItemStack ICON = new ItemStack(Items.TOTEM_OF_UNDYING);

    public TotemHud() { super("Totem HUD", "HUD", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int n = mc.player.getInventory().count(Items.TOTEM_OF_UNDYING);
        int x = mc.getWindow().getScaledWidth() / 2 + 100;
        int y = mc.getWindow().getScaledHeight() - 20;
        mc.getItemRenderer().renderGuiItemIcon(m, ICON, x, y);
        mc.textRenderer.drawWithShadow(m, "x" + n, x + 18, y + 5, n == 0 ? 0xFF5555 : 0xFFD54F);
    }
}
