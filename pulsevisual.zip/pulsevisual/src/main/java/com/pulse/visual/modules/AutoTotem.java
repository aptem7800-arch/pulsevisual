package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Keeps a totem in the off-hand. Many servers ban this, use on your own world. */
public class AutoTotem extends Module {
    private int cooldown;

    public AutoTotem() { super("Auto Totem", "Auto", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.interactionManager == null) return;
        if (++cooldown < 4) return;
        cooldown = 0;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return;

        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.main.get(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slot, 40,
                        SlotActionType.SWAP, mc.player);
                return;
            }
        }
    }
}
