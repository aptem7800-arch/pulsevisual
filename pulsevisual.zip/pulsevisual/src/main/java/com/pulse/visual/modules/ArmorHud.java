package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    public ArmorHud() { super("Armor HUD", "HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int x = 4;
        int y = 4;
        for (int i = 3; i >= 0; i--) {
            ItemStack s = mc.player.getInventory().armor.get(i);
            if (!s.isEmpty()) {
                mc.getItemRenderer().renderGuiItemIcon(m, s, x, y);
                if (s.isDamageable()) {
                    int pct = (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage();
                    mc.textRenderer.drawWithShadow(m, pct + "%", x + 20, y + 5, pct < 15 ? 0xFF5555 : 0xFFFFFF);
                }
            }
            y += 18;
        }
    }
}
