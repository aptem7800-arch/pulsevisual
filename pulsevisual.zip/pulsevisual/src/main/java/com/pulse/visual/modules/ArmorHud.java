package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    public ArmorHud() { super("Armor HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int x = mc.getWindow().getScaledWidth() - 22;
        int y = mc.getWindow().getScaledHeight() / 2 - 36;
        for (int i = 3; i >= 0; i--) {
            ItemStack s = mc.player.getInventory().armor.get(i);
            if (!s.isEmpty()) {
                mc.getItemRenderer().renderGuiItemIcon(m, s, x, y);
                if (s.isDamageable()) {
                    int pct = (s.getMaxDamage() - s.getDamage()) * 100 / s.getMaxDamage();
                    String txt = pct + "%";
                    mc.textRenderer.drawWithShadow(m, txt,
                            x - 3 - mc.textRenderer.getWidth(txt), y + 5, 0xFFFFFF);
                }
            }
            y += 18;
        }
    }
}
