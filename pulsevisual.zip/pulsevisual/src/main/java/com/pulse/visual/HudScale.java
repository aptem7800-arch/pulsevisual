package com.pulse.visual;

/** Global HUD scale, 50% to 150%. 100% is the normal size. */
public final class HudScale {
    public static int percent = 100;
    private HudScale() {}
    public static float factor() { return percent / 100.0f; }
}
