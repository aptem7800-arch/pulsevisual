package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/** The creature you are currently looking at or fighting. Dropped when 5+ blocks away. */
public final class Focus {
    private static LivingEntity target;

    private Focus() {}

    public static LivingEntity get() { return target; }

    public static void set(Entity e) {
        if (e instanceof LivingEntity le) target = le;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            target = null;
            return;
        }
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) target = le;
        LivingEntity t = target;
        if (t != null && (t.isRemoved() || !t.isAlive() || mc.player.distanceTo(t) > 5f)) target = null;
    }
}
