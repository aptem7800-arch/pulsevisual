package com.pulse.visual;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;

public final class Stats {
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastL, lastR;
    private static int frames, fps;
    private static long fpsTime = System.currentTimeMillis();

    private Stats() {}

    public static void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean l = mc.options.attackKey.isPressed();
        boolean r = mc.options.useKey.isPressed();
        if (l && !lastL) LEFT.addLast(now);
        if (r && !lastR) RIGHT.addLast(now);
        lastL = l;
        lastR = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.pollFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.pollFirst();
    }

    public static void frame() {
        frames++;
        long now = System.currentTimeMillis();
        if (now - fpsTime >= 1000) {
            fps = frames;
            frames = 0;
            fpsTime = now;
        }
    }

    public static int fps() { return fps; }
    public static int leftCps() { return LEFT.size(); }
    public static int rightCps() { return RIGHT.size(); }
}
