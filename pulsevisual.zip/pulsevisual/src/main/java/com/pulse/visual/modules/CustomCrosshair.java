package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.HudScale;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

/** Replaces the vanilla crosshair with a themed dot + cross. Hides the vanilla one while on. */
public class CustomCrosshair extends Module {
    public static int size = 8;

    public CustomCrosshair() { super("Custom Crosshair", "Visual", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        float scale = HudScale.factor();
        int s = Math.round(size * scale);
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int c = 0xFF000000 | Gfx.accent();
        int thickness = Math.max(1, s / 8);
        int gap = s / 3;

        DrawableHelper.fill(m, cx - thickness / 2, cy - s, cx + thickness / 2, cy - gap, c);
        DrawableHelper.fill(m, cx - thickness / 2, cy + gap, cx + thickness / 2, cy + s, c);
        DrawableHelper.fill(m, cx - s, cy - thickness / 2, cx - gap, cy + thickness / 2, c);
        DrawableHelper.fill(m, cx + gap, cy - thickness / 2, cx + s, cy + thickness / 2, c);
        DrawableHelper.fill(m, cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFFFFFF);
    }
}
