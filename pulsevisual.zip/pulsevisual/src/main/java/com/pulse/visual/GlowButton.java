package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.util.function.Supplier;

/** Rounded matte button. Off = white outline, on = glowing neon purple. No ON/OFF text. */
public class GlowButton {
    private final int x, y, w, h;
    private final String label;
    private final Supplier<Boolean> state;
    private final Runnable action;
    private float anim;

    public GlowButton(int x, int y, int w, int h, String label, Supplier<Boolean> state, Runnable action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.state = state;
        this.action = action;
        this.anim = (state != null && state.get()) ? 1f : 0f;
    }

    public boolean click(double mx, double my) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            action.run();
            return true;
        }
        return false;
    }

    public void render(MatrixStack m, int mx, int my) {
        boolean on = state != null && state.get();
        anim += ((on ? 1f : 0f) - anim) * 0.3f;
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;

        if (anim > 0.05f) {
            int a = (int) (80 * anim);
            Gfx.roundRect(m, x - 2, y - 2, w + 4, h + 4, 6, (a << 24) | Gfx.PURPLE);
        }
        int border = 0xFF000000 | Gfx.lerp(0xFFFFFF, Gfx.PURPLE, anim);
        Gfx.roundBorder(m, x, y, w, h, 4, border, hover ? 0xFF1E1E26 : 0xFF121217);

        var tr = MinecraftClient.getInstance().textRenderer;
        int tc = Gfx.lerp(0xE0E0E0, 0xE9C8FF, anim);
        tr.drawWithShadow(m, label, x + (w - tr.getWidth(label)) / 2f, y + (h - 8) / 2f, 0xFF000000 | tc);
    }
}
