package com.pulse.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.util.function.Supplier;

/** A nav / action pill: no border when off (just muted text), solid accent fill when on.
 *  Used for the category tabs, the close button and the cycle-style settings buttons.
 *  Debounced so one touchscreen tap can't register as several clicks. */
public class GlowButton {
    private static final long DEBOUNCE_MS = 180;

    private final int x, y, w, h;
    private final String label;
    private final Supplier<Boolean> state;
    private final Runnable action;
    private float anim;
    private long lastClick = 0;

    public GlowButton(int x, int y, int w, int h, String label, Supplier<Boolean> state, Runnable action) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.state = state;
        this.action = action;
        this.anim = (state != null && state.get()) ? 1f : 0f;
    }

    public boolean click(double mx, double my) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            long now = System.currentTimeMillis();
            if (now - lastClick >= DEBOUNCE_MS) {
                lastClick = now;
                action.run();
            }
            return true;
        }
        return false;
    }

    public void render(MatrixStack m, int mx, int my) {
        boolean on = state != null && state.get();
        anim += ((on ? 1f : 0f) - anim) * 0.3f;
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;

        if (anim > 0.4f) {
            int glowA = (int) (55 * ((anim - 0.4f) / 0.6f));
            Gfx.roundRect(m, x - 2, y - 2, w + 4, h + 4, 7, (glowA << 24) | Gfx.accent());
        }
        if (anim > 0.02f) {
            int bg = Gfx.lerp(0x1A1A20, Gfx.accent(), anim);
            Gfx.roundRect(m, x, y, w, h, 5, 0xFF000000 | bg);
        } else if (hover) {
            Gfx.roundRect(m, x, y, w, h, 5, 0xFF17171D);
        }

        var tr = MinecraftClient.getInstance().textRenderer;
        int tc = Gfx.lerp(0xA4A4AE, 0x120014, anim);
        tr.drawWithShadow(m, label, x + (w - tr.getWidth(label)) / 2f, y + (h - 8) / 2f, 0xFF000000 | tc);
    }
}
