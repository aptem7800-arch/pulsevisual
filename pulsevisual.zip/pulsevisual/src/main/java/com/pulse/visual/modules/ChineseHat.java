package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;

/** A cone-shaped hat of purple particles above the head of you and nearby players. */
public class ChineseHat extends Module {
    private static final double[] H = {0.0, 0.0, 0.0, 0.12, 0.24, 0.34};
    private static final double[] R = {0.55, 0.55, 0.55, 0.38, 0.20, 0.06};
    private double angle;

    public ChineseHat() { super("Chinese Hat", "Visual", false); }

    private void hat(MinecraftClient mc, Entity e) {
        for (int k = 0; k < H.length; k++) {
            double a = angle + k * (Math.PI * 2.0 / H.length);
            mc.world.addParticle(ParticleTypes.WITCH,
                    e.getX() + Math.cos(a) * R[k],
                    e.getY() + e.getHeight() + 0.05 + H[k],
                    e.getZ() + Math.sin(a) * R[k],
                    0, 0, 0);
        }
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        angle += 0.35;
        hat(mc, mc.player);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (mc.player.squaredDistanceTo(p) > 24.0 * 24.0) continue;
            hat(mc, p);
        }
    }
}
