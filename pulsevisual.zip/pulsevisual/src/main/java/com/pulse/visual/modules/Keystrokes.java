package com.pulse.visual.modules;

import com.pulse.visual.Module;
import com.pulse.visual.Stats;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

public class Keystrokes extends Module {
    public Keystrokes() { super("Keystrokes", "Info", true); }

    private void key(MatrixStack m, MinecraftClient mc, int x, int y, int w, int h, String label, boolean down) {
        DrawableHelper.fill(m, x, y, x + w, y + h, down ? 0xB0FFFFFF : 0x90000000);
        mc.textRenderer.draw(m, label, x + (w - mc.textRenderer.getWidth(label)) / 2f,
                y + (h - 8) / 2f, down ? 0xFF000000 : 0xFFFFFFFF);
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        var o = mc.options;
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int x0 = w - 70;
        int y0 = Math.min(h / 2 + 40, h - 100);

        key(m, mc, x0 + 20, y0, 18, 18, "W", o.forwardKey.isPressed());
        key(m, mc, x0, y0 + 20, 18, 18, "A", o.leftKey.isPressed());
        key(m, mc, x0 + 20, y0 + 20, 18, 18, "S", o.backKey.isPressed());
        key(m, mc, x0 + 40, y0 + 20, 18, 18, "D", o.rightKey.isPressed());
        key(m, mc, x0, y0 + 40, 58, 14, "SPACE", o.jumpKey.isPressed());
        key(m, mc, x0, y0 + 56, 28, 14, "SHFT", o.sneakKey.isPressed());
        key(m, mc, x0 + 30, y0 + 56, 28, 14, "CTRL", o.sprintKey.isPressed());
        key(m, mc, x0, y0 + 72, 28, 16, "L " + Stats.leftCps(), o.attackKey.isPressed());
        key(m, mc, x0 + 30, y0 + 72, 28, 16, "R " + Stats.rightCps(), o.useKey.isPressed());
    }
}
