package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class PingClock extends Module {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public PingClock() { super("Ping / Clock", "HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int ping = -1;
        if (mc.player != null && mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String s = (ping >= 0 ? "Ping: " + ping + "ms" : "Ping: --") + "   " + LocalTime.now().format(FMT);
        int w = mc.getWindow().getScaledWidth();
        mc.textRenderer.drawWithShadow(m, s, w - mc.textRenderer.getWidth(s) - 4, 95, 0xCCCCCC);
    }
}
