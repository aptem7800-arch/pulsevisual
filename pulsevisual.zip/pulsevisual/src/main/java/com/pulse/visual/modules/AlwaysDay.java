package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;

/** Client-side only: the sky stays at noon. Other players and the server are not affected. */
public class AlwaysDay extends Module {
    public AlwaysDay() { super("Always Day", "World", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world != null) mc.world.setTimeOfDay(6000L);
    }
}
