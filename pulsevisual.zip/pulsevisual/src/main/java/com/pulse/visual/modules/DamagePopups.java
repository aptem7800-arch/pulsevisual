package com.pulse.visual.modules;

import com.pulse.visual.Focus;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/** Floating "-3.0" / "+2.0" numbers near the crosshair when the target loses or gains health. */
public class DamagePopups extends Module {
    private static class Popup {
        String text;
        long born;
        int color;
        int dx;
    }

    private final List<Popup> popups = new ArrayList<>();
    private LivingEntity tracked;
    private float lastHp;

    public DamagePopups() { super("Damage Popups", "Info", true); }

    private void check(LivingEntity t) {
        float hp = t.getHealth();
        float d = lastHp - hp;
        if (d > 0.05f) add(String.format(Locale.ROOT, "-%.1f", d), 0xFF5555);
        else if (d < -0.05f) add(String.format(Locale.ROOT, "+%.1f", -d), 0x55FF55);
        lastHp = hp;
    }

    private void add(String text, int color) {
        Popup p = new Popup();
        p.text = text;
        p.color = color;
        p.born = System.currentTimeMillis();
        p.dx = ThreadLocalRandom.current().nextInt(-20, 21);
        popups.add(p);
    }

    @Override
    public void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        popups.removeIf(p -> now - p.born > 1000);

        LivingEntity f = Focus.get();
        if (f != tracked) {
            if (tracked != null) check(tracked);
            tracked = f;
            lastHp = f != null ? f.getHealth() : 0f;
            return;
        }
        if (tracked != null) check(tracked);
    }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        long now = System.currentTimeMillis();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        for (Popup p : popups) {
            float t = (now - p.born) / 1000f;
            int alpha = (int) (255 * (1f - t));
            if (alpha < 8) continue;
            int y = h / 2 - 25 - (int) (t * 25);
            int x = w / 2 + p.dx - mc.textRenderer.getWidth(p.text) / 2;
            mc.textRenderer.drawWithShadow(m, p.text, x, y, (alpha << 24) | p.color);
        }
    }
}
