package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Locale;

public class CoordsHud extends Module {
    public CoordsHud() { super("Coords HUD", "HUD", true); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        PlayerEntity p = mc.player;
        double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
        double speed = Math.sqrt(dx * dx + dz * dz) * 20.0;
        String s = String.format(Locale.ROOT, "XYZ %d %d %d  %s  %.1f b/s",
                (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()),
                p.getHorizontalFacing().asString(), speed);
        mc.textRenderer.drawWithShadow(m, s, 4, 80, 0xFFFFFF);
    }
}
