package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvents;

/** Plays a crisp sound every time you land a hit, on top of the normal attack sound. */
public class HitSound extends Module {
    public HitSound() { super("Hit Sound", "Info", false); }

    @Override
    public void onAttack(Entity e) {
        play(MinecraftClient.getInstance(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK);
    }
}
