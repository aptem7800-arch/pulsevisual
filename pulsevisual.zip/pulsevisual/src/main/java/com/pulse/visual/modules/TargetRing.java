package com.pulse.visual.modules;

import com.pulse.visual.Focus;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;

/** A slowly-rotating pyramid outline of purple particles around your current target. */
public class TargetRing extends Module {
    private double angle;

    public TargetRing() { super("Target Pyramid", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        LivingEntity t = Focus.get();
        if (t == null || mc.world == null) return;
        angle += 0.4;

        double baseR = t.getWidth() * 0.9 + 0.25;
        double baseY = t.getY() + 0.05;
        double apexY = t.getY() + t.getHeight() + 0.5;
        int corners = 4;

        for (int i = 0; i < corners; i++) {
            double a = angle + i * (Math.PI * 2.0 / corners);
            double bx = t.getX() + Math.cos(a) * baseR;
            double bz = t.getZ() + Math.sin(a) * baseR;
            mc.world.addParticle(ParticleTypes.WITCH, bx, baseY, bz, 0, 0, 0);
            // a couple of points along each edge climbing toward the apex
            for (int k = 1; k <= 2; k++) {
                double f = k / 3.0;
                mc.world.addParticle(ParticleTypes.WITCH,
                        bx + (t.getX() - bx) * f, baseY + (apexY - baseY) * f, bz + (t.getZ() - bz) * f,
                        0, 0, 0);
            }
        }
        mc.world.addParticle(ParticleTypes.DRAGON_BREATH, t.getX(), apexY, t.getZ(), 0, 0, 0);
    }
}
