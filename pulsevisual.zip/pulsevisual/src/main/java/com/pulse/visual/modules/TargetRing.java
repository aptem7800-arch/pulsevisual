package com.pulse.visual.modules;

import com.pulse.visual.Focus;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;

/** A purple ring of particles spinning above the head of your target. */
public class TargetRing extends Module {
    private double angle;

    public TargetRing() { super("Target Ring", "Visual", false); }

    @Override
    public void tick(MinecraftClient mc) {
        LivingEntity t = Focus.get();
        if (t == null || mc.world == null) return;
        angle += 0.5;
        double r = t.getWidth() * 0.8 + 0.2;
        double y = t.getY() + t.getHeight() + 0.1;
        for (int i = 0; i < 2; i++) {
            double a = angle + i * Math.PI;
            mc.world.addParticle(ParticleTypes.WITCH,
                    t.getX() + Math.cos(a) * r, y, t.getZ() + Math.sin(a) * r, 0, 0, 0);
        }
    }
}
