package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision: no darkness in caves or at night. */
public class Fullbright extends Module {
    private boolean applied;

    public Fullbright() { super("Fullbright", "World", false); }

    @Override
    public void update(MinecraftClient mc) {
        if (mc.player == null) return;
        if (enabled) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 300) {
                mc.player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
            }
            applied = true;
        } else if (applied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }
}
