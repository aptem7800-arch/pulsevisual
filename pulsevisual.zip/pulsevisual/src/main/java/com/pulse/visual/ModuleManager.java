package com.pulse.visual;

import com.pulse.visual.modules.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    public static final String[] CATEGORIES = {"HUD", "Info", "Visual", "Auto"};

    private final List<Module> modules = List.of(
            new TargetHud(),
            new ArmorHud(),
            new PotionHud(),
            new InventoryHud(),
            new TotemHud(),
            new Keystrokes(),
            new FpsCps(),
            new HitCounter(),
            new CooldownIndicator(),
            new CritIndicator(),
            new AimAssist(),
            new MobAura(),
            new AutoTotem(),
            new PurpleParticles(),
            new PurpleHitbox(),
            new AlertHud(),
            new Trails(),
            new Fullbright(),
            new FpsBoost()
    );

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("pulsevisual.properties");

    public ModuleManager() { load(); }

    public List<Module> all() { return modules; }

    private String key(Module m) { return m.name.replace(' ', '_'); }

    private void load() {
        try {
            if (!Files.exists(file)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file)) { p.load(in); }
            for (Module m : modules) {
                String v = p.getProperty(key(m));
                if (v != null) m.enabled = Boolean.parseBoolean(v);
            }
            String sv = p.getProperty("Aim_Smoothness");
            if (sv != null) AimAssist.smoothness = Math.max(0, Math.min(10, Integer.parseInt(sv.trim())));
        } catch (Exception ignored) {}
    }

    public void save() {
        try {
            Properties p = new Properties();
            for (Module m : modules) p.setProperty(key(m), String.valueOf(m.enabled));
            p.setProperty("Aim_Smoothness", String.valueOf(AimAssist.smoothness));
            try (OutputStream out = Files.newOutputStream(file)) { p.store(out, "PulseVisual"); }
        } catch (Exception ignored) {}
    }

    public void tick(MinecraftClient mc) {
        for (Module m : modules) m.update(mc);
        if (mc.player == null) return;
        for (Module m : modules) if (m.enabled) m.tick(mc);
    }

    public void render(MatrixStack matrices, MinecraftClient mc) {
        if (mc.player == null || mc.options.hudHidden) return;
        for (Module m : modules) if (m.enabled) m.render(matrices, mc);
    }

    public void renderWorld(WorldRenderContext ctx) {
        for (Module m : modules) if (m.enabled) m.renderWorld(ctx);
    }

    public void onAttack(Entity target) {
        for (Module m : modules) if (m.enabled) m.onAttack(target);
    }
}
