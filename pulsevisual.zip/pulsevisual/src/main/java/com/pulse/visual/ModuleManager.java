package com.pulse.visual;

import com.pulse.visual.modules.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    public static final String[] CATEGORIES = {"HUD", "Info", "Visual", "World", "Auto", "Settings"};

    private final List<Module> modules = List.of(
            new TargetHud(),
            new ArmorHud(),
            new PotionHud(),
            new InventoryHud(),
            new TotemHud(),
            new CoordsHud(),
            new WaypointHud(),
            new Watermark(),
            new Keystrokes(),
            new FpsCps(),
            new PingClock(),
            new HitCounter(),
            new CooldownIndicator(),
            new CritIndicator(),
            new HitSound(),
            new DamagePopups(),
            new AimAssist(),
            new AutoSprint(),
            new MobAura(),
            new AutoTotem(),
            new PurpleParticles(),
            new PurpleHitbox(),
            new AlertHud(),
            new Zoom(),
            new CustomCrosshair(),
            new BlockOutline(),
            new WaypointBeam(),
            new HotbarAccent(),
            new Trails(),
            new TargetRing(),
            new ChineseHat(),
            new JumpCircle(),
            new Fullbright(),
            new AlwaysDay(),
            new NoRain(),
            new FpsBoost()
    );

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("pulsevisual.properties");

    public ModuleManager() { load(); }

    public List<Module> all() { return modules; }

    private String key(Module m) { return m.name.replace(' ', '_'); }

    private void load() {
        try {
            if (!Files.exists(file)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file)) { p.load(in); }
            for (Module m : modules) {
                String v = p.getProperty(key(m));
                if (v != null) m.enabled = Boolean.parseBoolean(v);
            }
            String sv = p.getProperty("Aim_Smoothness");
            if (sv != null) AimAssist.smoothness = Math.max(0, Math.min(10, Integer.parseInt(sv.trim())));
            String rv = p.getProperty("Aim_Range");
            if (rv != null) AimAssist.range = Math.max(4, Math.min(6, Integer.parseInt(rv.trim())));
            String hv = p.getProperty("Aim_Hostile");
            if (hv != null) AimAssist.hostile = Boolean.parseBoolean(hv);
            String pv = p.getProperty("Aim_Passive");
            if (pv != null) AimAssist.passive = Boolean.parseBoolean(pv);
            String th = p.getProperty("Theme");
            if (th != null) Theme.index = Math.max(0, Math.min(Theme.NAMES.length - 1, Integer.parseInt(th.trim())));
            String hs = p.getProperty("HUD_Scale");
            if (hs != null) HudScale.percent = Math.max(50, Math.min(150, Integer.parseInt(hs.trim())));
            String cs = p.getProperty("Crosshair_Size");
            if (cs != null) com.pulse.visual.modules.CustomCrosshair.size = Math.max(4, Math.min(16, Integer.parseInt(cs.trim())));
            Waypoints.deserialize(p.getProperty("Waypoints"));
            String om = p.getProperty("Outline_Color_Mode");
            if (om != null) com.pulse.visual.modules.BlockOutline.colorMode = Math.max(0, Math.min(2, Integer.parseInt(om.trim())));
        } catch (Exception ignored) {}
    }

    public void save() {
        try {
            Properties p = new Properties();
            for (Module m : modules) p.setProperty(key(m), String.valueOf(m.enabled));
            p.setProperty("Aim_Smoothness", String.valueOf(AimAssist.smoothness));
            p.setProperty("Aim_Range", String.valueOf(AimAssist.range));
            p.setProperty("Aim_Hostile", String.valueOf(AimAssist.hostile));
            p.setProperty("Aim_Passive", String.valueOf(AimAssist.passive));
            p.setProperty("Theme", String.valueOf(Theme.index));
            p.setProperty("HUD_Scale", String.valueOf(HudScale.percent));
            p.setProperty("Crosshair_Size", String.valueOf(com.pulse.visual.modules.CustomCrosshair.size));
            p.setProperty("Waypoints", Waypoints.serialize());
            p.setProperty("Outline_Color_Mode", String.valueOf(com.pulse.visual.modules.BlockOutline.colorMode));
            try (OutputStream out = Files.newOutputStream(file)) { p.store(out, "PulseVisual"); }
        } catch (Exception ignored) {}
    }

    public void tick(MinecraftClient mc) {
        for (Module m : modules) m.update(mc);
        if (mc.player == null) return;
        for (Module m : modules) if (m.enabled) m.tick(mc);
    }

    public void render(MatrixStack matrices, MinecraftClient mc) {
        if (mc.player == null || mc.options.hudHidden) return;
        for (Module m : modules) if (m.enabled) m.render(matrices, mc);
    }

    public void renderWorld(WorldRenderContext ctx) {
        for (Module m : modules) if (m.enabled) m.renderWorld(ctx);
    }

    public void onAttack(Entity target) {
        for (Module m : modules) if (m.enabled) m.onAttack(target);
    }
}
