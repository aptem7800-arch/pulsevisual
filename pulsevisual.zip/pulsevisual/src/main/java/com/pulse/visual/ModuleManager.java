package com.pulse.visual;

import com.pulse.visual.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import java.util.List;

public class ModuleManager {
    private final List<Module> modules = List.of(
            new TargetHud(),
            new ArmorHud(),
            new PotionHud(),
            new InventoryHud(),
            new CooldownIndicator(),
            new HitCounter()
    );

    public List<Module> all() { return modules; }

    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        for (Module m : modules) if (m.enabled) m.tick(mc);
    }

    public void render(MatrixStack matrices, MinecraftClient mc) {
        if (mc.player == null || mc.options.hudHidden) return;
        for (Module m : modules) if (m.enabled) m.render(matrices, mc);
    }

    public void onAttack(Entity target) {
        for (Module m : modules) if (m.enabled) m.onAttack(target);
    }
}
