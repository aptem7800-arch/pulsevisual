package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;

/** Client-side only: hides rain and thunder. */
public class NoRain extends Module {
    public NoRain() { super("No Rain", "World", false); }

    @Override
    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        mc.world.setRainGradient(0f);
        mc.world.setThunderGradient(0f);
    }
}
