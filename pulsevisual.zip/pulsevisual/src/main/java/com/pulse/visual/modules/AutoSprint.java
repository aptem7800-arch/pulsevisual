package com.pulse.visual.modules;

import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

/** Keeps you sprinting forward automatically, so you don't need to hold the sprint key. */
public class AutoSprint extends Module {
    public AutoSprint() { super("Auto Sprint", "Auto", false); }

    @Override
    public void tick(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        boolean movingForward = mc.options.forwardKey.isPressed();
        boolean canSprint = !p.isSneaking() && p.getHungerManager().getFoodLevel() > 6;
        if (movingForward && canSprint && !p.isSprinting()) {
            p.setSprinting(true);
        } else if ((!movingForward || !canSprint) && p.isSprinting()) {
            p.setSprinting(false);
        }
    }
}
