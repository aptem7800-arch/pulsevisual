package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.util.math.MatrixStack;

/** A themed accent frame drawn just outside the vanilla hotbar, as four thin opaque strips
 *  (no reliance on transparent fills), so it can never paint over and hide the hotbar itself. */
public class HotbarAccent extends Module {
    public HotbarAccent() { super("Hotbar Accent", "Visual", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int x = w / 2 - 91 - 2;
        int y = h - 22 - 2;
        int ww = 182 + 4;
        int hh = 22 + 4;
        int c = 0xFF000000 | Gfx.accent();

        DrawableHelper.fill(m, x, y, x + ww, y + 1, c);               // top edge
        DrawableHelper.fill(m, x, y + hh - 1, x + ww, y + hh, c);     // bottom edge
        DrawableHelper.fill(m, x, y, x + 1, y + hh, c);               // left edge
        DrawableHelper.fill(m, x + ww - 1, y, x + ww, y + hh, c);     // right edge
    }
}
