package com.pulse.visual.modules;

import com.pulse.visual.Gfx;
import com.pulse.visual.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

/** A themed glow frame drawn just outside the vanilla hotbar. The hotbar itself is untouched. */
public class HotbarAccent extends Module {
    public HotbarAccent() { super("Hotbar Accent", "Visual", false); }

    @Override
    public void render(MatrixStack m, MinecraftClient mc) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int x = w / 2 - 91 - 2;
        int y = h - 22 - 2;
        Gfx.roundBorder(m, x, y, 182 + 4, 22 + 4, 5, 0xFF000000 | Gfx.accent(), 0x00000000);
    }
}
