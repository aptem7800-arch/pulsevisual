package com.pulse.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class PulseMod implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static boolean menuKeyDown;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // The menu key is polled directly, so it does not show up in the Controls screen.
            boolean down = client.getWindow() != null
                    && InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_M);
            if (down && !menuKeyDown && client.currentScreen == null && client.player != null) {
                client.setScreen(new ModuleScreen());
            }
            menuKeyDown = down;

            Stats.tick(client);
            Focus.tick(client);
            MODULES.tick(client);
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            Stats.frame();
            MODULES.render(matrices, MinecraftClient.getInstance());
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> MODULES.renderWorld(ctx));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) {
                Focus.set(entity);
                MODULES.onAttack(entity);
            }
            return ActionResult.PASS;
        });
    }
}
