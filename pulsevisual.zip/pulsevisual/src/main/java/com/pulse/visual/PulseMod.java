package com.pulse.visual;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class PulseMod implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static boolean menuKeyDown;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // The menu key is polled directly, so it does not show up in the Controls screen.
            boolean down = client.getWindow() != null
                    && InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_M);
            if (down && !menuKeyDown && client.currentScreen == null && client.player != null) {
                client.setScreen(new ModuleScreen());
            }
            menuKeyDown = down;

            Stats.tick(client);
            MODULES.tick(client);
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            Stats.frame();
            MODULES.render(matrices, MinecraftClient.getInstance());
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> MODULES.renderWorld(ctx));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) MODULES.onAttack(entity);
            return ActionResult.PASS;
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                ClientCommandManager.literal("waypoint")
                        .then(ClientCommandManager.literal("add")
                                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                        .executes(ctx -> {
                                            String name = StringArgumentType.getString(ctx, "name");
                                            var p = MinecraftClient.getInstance().player;
                                            Waypoints.add(name, p.getX(), p.getY(), p.getZ());
                                            ctx.getSource().sendFeedback(Text.literal("§dWaypoint saved: " + name));
                                            return 1;
                                        })))
                        .then(ClientCommandManager.literal("del")
                                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                        .executes(ctx -> {
                                            String name = StringArgumentType.getString(ctx, "name");
                                            boolean removed = Waypoints.remove(name);
                                            ctx.getSource().sendFeedback(Text.literal(
                                                    removed ? "§dRemoved: " + name : "§cNo such waypoint: " + name));
                                            return 1;
                                        })))));
    }
}
